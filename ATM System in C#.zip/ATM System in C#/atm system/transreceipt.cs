
using System.Diagnostics;
using System;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using System.Collections.Generic;
using System.Linq;



namespace atmsystem
{
	public partial class transreceipt
	{
		public transreceipt()
		{
			InitializeComponent();
		}

        private void Button1_Click(object sender, EventArgs e)
        {

        }
		
	}
}
